package parcial1_321;


public abstract class EspecieMarina implements Movible{
    private String nombre;
    private String tanqueUbicacion;
    private TipoAgua tipoAgua;

    
    //CONSTRUCTOR
    public EspecieMarina(String nombre, String tanqueUbicacion, TipoAgua tipoAgua) {
        this.nombre = nombre;
        this.tanqueUbicacion = tanqueUbicacion;
        this.tipoAgua = tipoAgua;
    }
    
    //METODO ABSTRACTO PARA REPRODUSIRSE
    public abstract void reproducirse();
    
    //METODO ABSTRACTO PARA RESPIRAR
    public abstract void respirar();

    
    //METODO TOSTRING
    @Override
    public String toString() {
        return "EspecieMarina -----> " + "nombre=" + nombre + ", tanqueUbicacion=" + tanqueUbicacion + ", tipoAgua=" + tipoAgua + " ";
    }
    
    
    //METODO GET PARA NOMBRE
    public String getNombre(){
        return this.nombre;
    }
    
    //METODO GET PARA TIPOAGUA
    public TipoAgua getTipoAgua(){
        return this.tipoAgua;
    }
    
    //METODO EQUALS
    public boolean equals(Object o){
        boolean toReturn = true;
        if(!(o instanceof EspecieMarina)){
            toReturn = false;
        }
        EspecieMarina em = (EspecieMarina) o;
    return this.nombre.equals(em.nombre) && this.tanqueUbicacion.equals(em.tanqueUbicacion);
    }
    
    
    //METODO HASHCODE
    public int hashCode(){
        return nombre.hashCode() + tanqueUbicacion.hashCode();
    }
    
    
    
    
}
