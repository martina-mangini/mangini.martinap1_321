package parcial1_321;

import java.util.ArrayList;

public class AcuarioMarino {
    private ArrayList<EspecieMarina> especies;

    
    //CONSTRUCTOR
    public AcuarioMarino() {
        this.especies = new ArrayList<>();
    }
    
    
    //METODO PARA AGREGAR ESPECIE
    public void agregarEspecie(EspecieMarina especie) throws EspecieRepetidaException {
        if (especies.contains(especie)){
            throw new EspecieRepetidaException("Ya existe una especie con ese nombre y ubicacion");
        }
        especies.add(especie);
    }
    
    
    //METODO PARA MOSTRAR PLANTAS
    public String mostrarEspecies(){
        StringBuilder sb = new StringBuilder();
        sb.append("ESPECIES REGISTRADAS: \n");
        for(EspecieMarina em : especies){
            sb.append(em.toString() + '\n');
        }
        return sb.toString();
    }
    
    
    //METODO PARA FILTRAR POR TIPO DE AGUA
    public ArrayList<EspecieMarina> filtrarPorAgua (TipoAgua tipo){
        ArrayList<EspecieMarina> listaFiltrada = new ArrayList<>();
        for(EspecieMarina em : especies){
            if (em.getTipoAgua().equals(tipo)){
                listaFiltrada.add(em);
            }
        }
        return listaFiltrada;
    }
    
   
    
}
