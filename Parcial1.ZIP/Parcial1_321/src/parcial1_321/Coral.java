package parcial1_321;


public class Coral extends EspecieMarina implements Alimentados{
    private double profundidadIdeal;

    //CONSTRUCTOR
    public Coral(String nombre, String tanqueUbicacion, TipoAgua tipoAgua, double profundidadIdeal) {
        super(nombre, tanqueUbicacion, tipoAgua);
        this.profundidadIdeal = profundidadIdeal;
    }
    
    
    //METODO PARA ALIMENTAR
    @Override
    public void Alimentar(){
        System.out.println("CORAL ALIMENTADO");
    }
    
    
    //METODO PARA REPRODUCIRSE
    @Override
    public void reproducirse(){
        System.out.println("CORAL REPRODUCIDO");
    }
    
    
    //METODO PARA RESPIRAR
    public void respirar(){
        System.out.println("CORAL RESPIRANDO");
    }

    
    //METODO TOSTRING
    @Override
    public String toString() {
        return  super.toString() +  "profundidadIdeal =" + profundidadIdeal ;
    }
    
    
    //METODO PARA MOVERSE
    @Override
    public String moverEspecie(){
        return getNombre() + "NO ES MOVIBLE";
    }
}
