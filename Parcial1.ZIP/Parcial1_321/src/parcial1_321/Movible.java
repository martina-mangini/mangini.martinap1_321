package parcial1_321;


public interface Movible {
    public abstract String moverEspecie();
}
