package parcial1_321;


public class Molusco extends EspecieMarina {
    private String tipoConcha;

    
    //CONSTRUCTOR
    public Molusco(String nombre, String tanqueUbicacion, TipoAgua tipoAgua, String tipoConcha) {
        super(nombre, tanqueUbicacion, tipoAgua);
        this.tipoConcha = tipoConcha;
    }
    
    //METODO PARA REPRODUCIRSE
    @Override
    public void reproducirse(){
        System.out.println("MOLUSCO REPRODUCIDO");
    }
    
    
    //METODO PARA RESPIRAR
    public void respirar(){
        System.out.println("MOLUSCO RESPIRANDO");
    }

    
    //METODO TOSTRING
    @Override
    public String toString() {
        return super.toString() + "tipoConcha=" + tipoConcha ;
    }
    
    //METODO PARA MOVERSE
    @Override
    public String moverEspecie(){
        return getNombre() + "FUE MOVIDO";
    }
    
    
    
}
